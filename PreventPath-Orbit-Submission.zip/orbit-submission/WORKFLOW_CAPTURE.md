# PreventPath — Orbit Workflow Capture
## Z.ai x Orbit Builder Workflow Award
**Event**: VibeHack London 2026
**Date**: 2026-06-06
**Builder**: [To be captured]
**Team**: [To be captured]

---

## Project Snapshot

**Project Name**: PreventPath
**Mission**: NHS prevention navigator for England
**Tech Stack**:
- Frontend: Next.js 14 + TypeScript + Tailwind CSS
- UI Library: Aceternity UI + Framer Motion + Lucide React
- Rules Engine: TypeScript (separate module)

**Current Branch**: `feature/landing-page`
**Other Branches**: `main`, `rules-engine-safety`

---

## Workflow Timeline

### Phase 0: Discovery & Context Capture
**Time**: Session start (2026-06-06 ~20:37)

**User Provided Context**:
> We are building PreventPath, an NHS prevention navigator for England. It helps users understand what preventive health information may be missing, see possible NHS service routes, and prepare a copyable summary for a conversation with their registered GP practice, a participating community pharmacy, or another appropriate NHS service.

**Constraints Established**:
- Do not diagnose, prescribe, confirm eligibility, calculate clinical risk, book appointments, or replace NHS advice
- Use cautious wording: "may", "possible", "consider asking", "conversation starter"
- For GP routes: "your registered GP practice" (not "any GP")
- Keep urgent care separate from routine prevention routes
- Do not modify `src/lib/rules` unless explicitly asked

**Orbit Task**: Capture workflow for Z.ai x Orbit Builder Workflow Award submission. Track steps, prompts, design decisions, files changed, final outputs.

---

### Project Structure Discovered

**Frontend (feature/landing-page)**:
```
frontend/
├── src/
│   ├── app/
│   │   ├── layout.tsx
│   │   ├── page.tsx
│   │   ├── globals.css
│   │   └── fonts/
│   ├── components/
│   │   ├── HeroSection.tsx
│   │   ├── LandingNavbar.tsx
│   │   ├── LandingFooter.tsx
│   │   ├── CareJourneyDiagram.tsx
│   │   ├── PreventionRouteDiagram.tsx
│   │   ├── SafetyFirstPanel.tsx
│   │   ├── SafetyTrustStrip.tsx
│   │   ├── WhatItDoesNotDo.tsx
│   │   ├── WhatWeDoNotDoStrip.tsx
│   │   ├── MissingInformationCards.tsx
│   │   ├── PossibleRoutesSection.tsx
│   │   ├── CopyableSummaryPreview.tsx
│   │   ├── NhsConversationPreview.tsx
│   │   ├── FinalCTASection.tsx
│   │   ├── TechAndRulesSection.tsx
│   │   ├── RulesEngineFlow.tsx
│   │   ├── SafetyGateDiagram.tsx
│   │   ├── ServiceRouteMap.tsx
│   │   ├── QriskReadinessLock.tsx
│   │   ├── MissingMeasurementsGrid.tsx
│   │   └── ui/
│   │       ├── bento-grid.tsx
│   │       ├── magic-card.tsx
│   │       ├── matte-panel.tsx
│   │       └── shimmer-button.tsx
│   └── lib/
│       ├── constants.ts
│       └── copy.ts
├── package.json
├── tsconfig.json
├── tailwind.config.ts
└── next.config.mjs
```

**Rules Engine (rules-engine-safety branch)**:
```
src/lib/rules/
├── index.ts                    # Main exports
├── types.ts                    # TypeScript contracts
├── constants.ts                # Safety constants
├── safetyRules.ts              # Urgency assessment
├── missingMeasurements.ts      # Gap detection
├── healthCheckEligibility.ts   # NHS Health Check logic
├── screeningEligibility.ts     # Screening route hints
├── qriskReadiness.ts           # Qrisk educational readiness
├── recommendations.ts          # Frontend recommendation cards
├── gpSummary.ts                # Copyable GP text builder
├── assessPreventiveRoute.ts    # Main orchestrator
├── validation.ts               # Input validation
├── demoCases.ts                # Test cases
├── finalReviewTest.ts          # Integration tests
└── testDefensive.ts            # Defensive tests
```

---

## Commit History Summary (Pre-Session)

**Recent Landing Page Work** (74fa782 → 511126c):
- Hero section rewrite with patient-facing copy
- NHS cyan design tokens
- Aceternity UI integration
- NHS logo in navbar
- Information cards, possible routes, conversation preview components
- Final CTA and footer
- Safety components (What It Does Not Do, Safety Trust Strip)
- Visual diagrams (Care Journey, Prevention Route, Safety Gate, Rules Engine Flow, Service Route Map)
- Qrisk Readiness Lock component

**Rules Engine Work** (early commits):
- Modular TypeScript rules engine
- Safety constants and urgency assessment
- Missing measurements detection
- NHS Health Check eligibility
- Screening eligibility
- Qrisk readiness assessment
- GP summary builder
- Defensive input handling
- Integration tests
- Demo test cases

---

## Design Decisions Tracker
*To be populated as work proceeds*

| Decision | Context | Rationale |
|----------|---------|-----------|
| - | - | - |

---

## Prompts Used
*To be populated as work proceeds*

| Prompt | Response | Outcome |
|--------|----------|---------|
| - | - | - |

---

## Files Modified This Session
*To be populated as work proceeds*

| File | Change | Time |
|------|--------|------|
| - | - | - |

---

## Final Outputs
*To be populated at session end*

- [ ] Live demo URL
- [ ] Screenshots
- [ ] Team details
- [ ] Submission package

---

## Notes

- Local working tree was sparse (only LICENSE, untracked frontend/ directory)
- Had to `git checkout origin/feature/landing-page -- frontend/` to restore source
- Rules engine exists on separate `rules-engine-safety` branch
- CAVEMAN MODE active for terse communication style
- Orbie embodied: Observation mode (respond only when summoned)

---
*Last updated: 2026-06-06 20:40*